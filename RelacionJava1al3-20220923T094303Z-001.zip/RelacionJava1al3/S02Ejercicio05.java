public class S02Ejercicio05 {
	
	public static void main (String[] args) {
		int pesetas = 3000;
		double euros = pesetas / 166.386;
		
		System.out.println(pesetas+" pesetas son "+euros+" euros");
	}
}


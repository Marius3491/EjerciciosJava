
public class S01Ejercicio03 {
	
	public static void main (String[] args) {
		System.out.println("Leon \t Lion");
		System.out.println("Toro \t Bull");
		System.out.println("Avispa \t Wasp");
		System.out.println("Portatil \t Laptop");
		System.out.println("Buscar \t Search");
		System.out.println("Pagina \t Page");
		System.out.println("Navegador \t Browser");
		System.out.println("Interfaz \t Interface");
	}
}


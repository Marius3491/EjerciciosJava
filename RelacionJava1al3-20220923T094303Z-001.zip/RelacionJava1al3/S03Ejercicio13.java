import java.util.Scanner;
public class S03Ejercicio13 {
	
	public static void main (String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.print("Introduzca la nota del 1er examen: ");
	double nota1 = sc.nextDouble();
	System.out.print("Nota para el trimestre?: ");
	double n_final = sc.nextDouble();
	double nota2 = ((n_final*100)-(nota1*40))/60;
	
	System.out.println("Para tener un "+n_final+" en el trimestre");
	System.out.println(" necesita sacar un "+nota2+" en el segundo examen.");
	}
}


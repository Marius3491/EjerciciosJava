public class S02Ejercicio06 {
	
	public static void main (String[] args) {
		double baseimponible = 34.50;
		System.out.println("Base imponible :"+baseimponible);
		System.out.println("IVA(21%): "+baseimponible*0.21);
		System.out.println("Total: "+baseimponible*1.21);
	}
}


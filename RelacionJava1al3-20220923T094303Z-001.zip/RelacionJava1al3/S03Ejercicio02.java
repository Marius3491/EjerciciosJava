import java.util.Scanner;
public class S03Ejercicio02 {
	
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Introduce valor en Euros a convertir: ");
		double euro = sc.nextDouble();
		int pesetas = (int) (euro * 166.386);
		System.out.println("Euros: "+euro+" , "+"Pesetas: "+pesetas+".");
	}
}


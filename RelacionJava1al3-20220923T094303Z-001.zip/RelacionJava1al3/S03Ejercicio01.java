import java.util.Scanner;

public class S03Ejercicio01 {
	
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Introduce primer numero :");
		int num1 = sc.nextInt();
		System.out.print("Introduce segundo numero :");
		int num2 = sc.nextInt();
		
		System.out.println(num1+" x "+num2+" = "+(num1*num2));
	}
}


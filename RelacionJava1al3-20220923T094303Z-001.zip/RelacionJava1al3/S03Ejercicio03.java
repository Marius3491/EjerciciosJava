import java.util.Scanner;
public class S03Ejercicio03 {
	
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Introduce el valor en pesetas a convertir :");
		int pesetas = sc.nextInt();
		double euros = pesetas / 166.386;
		
		System.out.println("Pesetas: "+pesetas+","+"Euro: "+euros+" .");
	}
}


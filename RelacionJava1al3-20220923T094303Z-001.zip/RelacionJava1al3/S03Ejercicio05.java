import java.util.Scanner;
public class S03Ejercicio05 {
	
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Introduzca base del rectangulo en cm: ");
		double base = sc.nextDouble();
		System.out.print("Introduzca altura en cm: ");
		double altura = sc.nextDouble();
		System.out.println("Base: "+base+","+"Altura: "+altura+" ."+"Resultado: "+(base*altura)+"cm2.");
	}
}


import java.util.Scanner;
public class S03Ejercicio11 {
	
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Introduce kb para conversion :");
		double kb = sc.nextDouble();
		System.out.println(kb+" kb son "+(kb / 1024)+" mb.");
	}
}


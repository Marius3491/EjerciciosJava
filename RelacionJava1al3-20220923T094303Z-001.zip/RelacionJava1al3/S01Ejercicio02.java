
public class S01Ejercicio02 {
	
	public static void main (String[] args) {
		System.out.println("Mario Robles Garcia");
		System.out.println("Calle Gran Canaria 45");
		System.out.println("680855906");
	}
}


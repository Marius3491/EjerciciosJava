public class S02Ejercicio01 {
	
	public static void main (String[] args) {
		int x = 144;
		int y = 999;
		int suma;
		int resta;
		int mult;
		double division;
		
		suma=x+y;
		System.out.println("Suma :"+suma);
		resta=x-y;
		System.out.println("Resta :"+resta);
		mult=x*y;
		System.out.println("Multiplicacion: "+mult);
		division=(double)x/(double)y;
		System.out.println("Division: "+division);
	}
}


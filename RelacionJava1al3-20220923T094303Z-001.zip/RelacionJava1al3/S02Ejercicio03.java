
public class S02Ejercicio03 {
	
	public static void main (String[] args) {
		String nombre = "Mario";
		String direccion = "Gran Canaria 45";
		String telefono = "680855906";
		
		System.out.println("Nombre: "+nombre);
		System.out.println("Direccion: "+direccion);
		System.out.println("TLF: "+telefono);
		
		
	}
}



public class S01Ejercicio05 {
	
	public static void main (String[] args) {
		String rojo = "\033[31m";
		String verde = "\033[32m";
		String naranja = "\033[33m";
		String azul = "\033[34m";
		String morado = "\033[35m";
		String blanco = "\033[37m";
						
		System.out.println("Lunes\tMartes\tMiercoles\tJueves\tViernes");
		System.out.println("-----\t------\t---------\t------\t-------");
		System.out.println(rojo+"BDA\t"+morado+"PRG\t"+morado+"PRG\t\t"+blanco+"EDS\t"+rojo+"BDA");
		System.out.println(rojo+"BDA\t"+morado+"PRG\t"+morado+"PRG\t\t"+morado+"PRG\t"+rojo+"BDA");
		System.out.println(azul+"ING\t"+blanco+"EDS\t"+morado+"PRG\t\t"+morado+"PRG\t"+verde+"SIN");
		System.out.println("--------------------RECREO-----------------");
		System.out.println(blanco+"FOL\t"+blanco+"EDS\t"+azul+"ING\t\t"+morado+"PRG\t"+verde+"SIN");
		System.out.println(blanco+"FOL\t"+naranja+"LMS\t"+verde+"SIN\t\t"+verde+"SIN\t"+naranja+"LMS");
		System.out.println(blanco+"FOL\t"+naranja+"LMS\t"+verde+"SIN\t\t"+verde+"SIN\t"+naranja+"LMS");
	}
}


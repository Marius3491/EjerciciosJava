import java.util.Scanner;
public class S03Ejercicio07 {
	
	public static void main (String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.print("Introduzca base imponible: ");
	double baseimponible = sc.nextDouble();
	System.out.println("Base imponible: "+baseimponible);
	System.out.println("IVA %21: "+baseimponible*0.21);
	System.out.println("Total: "+baseimponible*1.21);
	}
}


import java.util.Scanner;
public class S03Ejercicio09 {
	
	public static void main (String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.print("Introduce altura del cono: ");
	double a = sc.nextDouble();
	System.out.print("Introduce el radio de la base: ");
	double r = sc.nextDouble();
	double vol = (1.0/3.0)*3.14*r*r*a;
	System.out.println("Volumen del Cono: "+vol+" cm3");
	}
}


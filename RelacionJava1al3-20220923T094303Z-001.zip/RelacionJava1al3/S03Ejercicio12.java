import java.util.Scanner;
public class S03Ejercicio12 {
	
	public static void main (String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.print("Introduce la base imponible: ");
	double baseimponible = sc.nextDouble();
	System.out.print("Introduce el tipo de IVA (general,reducido, o superreducido): ");
	String tipoiva = sc.next();
	System.out.print("Introduce el codigo promocional(nopro,mitad,meno5 o 5porc): ");
	String promocion = sc.next();
	
	int valoriva=0;
	
	switch(tipoiva){
		case "general":
		valoriva = 21;
		break;
		case "reducido":
		valoriva=10;
		break;
		case "superreducido":
		valoriva=4;
		break;
		
		default:
		System.out.println("tipo de IVA no valido");
	}
	
	double iva = (baseimponible*valoriva)/100;
	double sindesc = baseimponible + iva;
	
	double desc=0;
	
	switch(promocion){
		case "nopro":
		break;
		case "mitad":
		desc = sindesc / 2;
		break;
		case "meno5":
		desc = 5;
		break;
		case "5porc":
		desc= sindesc * 0.05;
		break;
		
		default:
		System.out.println("Codigo promocional no valido ");
	}
	 double valorfinal = sindesc - desc;
	 
	 System.out.println("Base Imponible: "+baseimponible);
	 System.out.println("IVA: ("+valoriva+"%) "+iva);
	 System.out.println("Precio con IVA: "+sindesc);
	 System.out.println("Codigo promocional"+"("+promocion+"): -"+desc);
	 System.out.println("Total: "+valorfinal);
	}
}


import java.util.Scanner;
public class S03Ejercicio08 {
	
	public static void main (String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.print("Por favor, introduzca horas trabajadas");
	int horas = sc.nextInt();
	System.out.println("Horas trabajadas: "+horas);
	System.out.println("Correspondencia salarial: "+horas*12+" euro.");
	}
}


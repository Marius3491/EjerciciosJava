public class S02Ejercicio04 {
	
	public static void main (String[] args) {
	double euros = 1.50;
	int pesetas = (int)(euros * 166.386);
	
	System.out.println("Euros: "+euros+", en peseta son: "+pesetas);
	}
}


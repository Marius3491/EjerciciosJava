import java.util.Scanner;
public class S03Ejercicio10 {
	
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Introduce Mb para conversion :");
		double mb = sc.nextDouble();
		System.out.println(mb+" Mb son "+(mb * 1024)+" kb.");
	}
}


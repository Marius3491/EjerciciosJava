public class S02Ejercicio02 {
	
	public static void main (String[] args) {
		String nombre = "Mario Robles Garcia";
		System.out.println(nombre);
	}
}


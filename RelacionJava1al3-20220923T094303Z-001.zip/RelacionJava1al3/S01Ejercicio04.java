
public class S01Ejercicio04 {
	
	public static void main (String[] args) {
		System.out.println("Lunes\tMartes\tMiercoles\tJueves\tViernes");
		System.out.println("-----\t------\t---------\t------\t-------");
		System.out.println("BDA\tPRG\tPRG\t\tEDS\tBDA");
		System.out.println("BDA\tPRG\tPRG\t\tPRG\tBDA");
		System.out.println("ING\tEDS\tPRG\t\tPRG\tSIN");
		System.out.println("--------------------RECREO-----------------");
		System.out.println("FOL\tEDS\tING\t\tPRG\tSIN");
		System.out.println("FOL\tLMS\tSIN\t\tSIN\tLMS");
		System.out.println("FOL\tLMS\tSIN\t\tSIN\tLMS");
	}
}


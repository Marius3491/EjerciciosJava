import java.util.Scanner;
public class S03Ejercicio04 {
	
	public static void main (String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Primer numero: ");
		double num1 = sc.nextDouble();
		System.out.print("Segundo numero: ");
		double num2 = sc.nextDouble();
		
		System.out.println(num1+"+"+num2+"= "+(num1+num2));
		System.out.println(num1+"-"+num2+"= "+(num1-num2));
		System.out.println(num1+"*"+num2+"= "+(num1*num2));
		System.out.println(num1+"/"+num2+"= "+(num1/num2));
		
	}
}

